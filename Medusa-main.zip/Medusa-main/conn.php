<?php
$con=mysqli_connect('localhost','root','','medusa');
if(!$con)
{
	die("Connecton failed! ".mysqli_connect_error());
}
else
{
}	
?>