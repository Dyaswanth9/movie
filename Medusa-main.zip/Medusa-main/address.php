<html>
<head>
<title>Address</title>
<link rel="stylesheet" href="adf.css">
</head>
<body>
    <div class="addform">
        <form action="adradd.php" method="POST">
            <p>Adress Line 1</p>
            <input type="street" name="ad1">
            <p>Adress Line 2</p>
            <input type="street" name="ad2"><br><br><br>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>